package com.lti.mypack.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.mypack.model.Customer;
import com.lti.mypack.model.Item;
import com.lti.mypack.model.ItemDetails;
import com.lti.mypack.model.Product;
import com.lti.mypack.modelOTM.CustomerX;
import com.lti.mypack.modelOTM.ItemX;

@Repository
@Transactional
public class ProductRepositoryImpl implements ProductRepository
{
	@PersistenceContext
	EntityManager eMan;
	

	@Override
	public String addProduct(Product product) {
		eMan.persist(product);
		return "Product Added";
	}

	@Override
	public List<Product> getAllProducts() {
		return eMan.createQuery("from Product").getResultList();
	}

	@Override
	public void doMapping() {
		
		//ONT TO ONE
		
		Customer cust=new Customer();
		cust.setId(100);
		cust.setName("Anna");
	
		Item its=new Item();
		its.setItemid(600);
		its.setItemname("Kino");
		

		/*ItemDetails itd=new ItemDetails();
		itd.setItdescid(199);
		itd.setDescription("Kollam");
		
		its.setIdetails(itd);*/
		
		cust.setItem(its);
		
		eMan.merge(cust) ;
		 
		System.out.println("OTM Done..");
		
		//ONE TO MANY <-> MANY TO ONE 
		
	/*	CustomerX custx=new CustomerX();
		custx.setCustid(101);
		
		ItemX item1=new ItemX();
		item1.setItemid(900);
		item1.setItemname("Puffs");
		
		ItemX item2=new ItemX();
		item2.setItemid(901);
		item2.setItemname("Cutlet");
		
		List<ItemX> list=new ArrayList<ItemX>();
		list.add(item1);
		list.add(item2);
		
		custx.setCustBoughtItems(list);
		
		eMan.persist(custx);
		
		System.out.println("OTM Done.."); */
		
		
		
	}

}
