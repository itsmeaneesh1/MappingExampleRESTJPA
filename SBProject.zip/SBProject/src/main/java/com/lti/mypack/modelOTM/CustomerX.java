package com.lti.mypack.modelOTM;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "cust002")
public class CustomerX 
{
	@Id
	private int customerid;
	private String name;
	
	//@OneToMany(cascade={CascadeType.PERSIST,CascadeType.REMOVE})
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="custID")
	List<ItemX> custBoughtItems;

	public int getCustid() {
		return customerid;
	}

	public void setCustid(int custid) {
		this.customerid = custid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ItemX> getCustBoughtItems() {
		return custBoughtItems;
	}

	public void setCustBoughtItems(List<ItemX> custBoughtItems) {
		this.custBoughtItems = custBoughtItems;
	}
	
}
