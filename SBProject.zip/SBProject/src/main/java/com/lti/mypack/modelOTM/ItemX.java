package com.lti.mypack.modelOTM;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="item002")
public class ItemX 
{
	@Id
	private int itemsid;
	private String itemname;
	
	public int getItemid() {
		return itemsid;
	}
	public void setItemid(int itemid) {
		this.itemsid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	
	
}
