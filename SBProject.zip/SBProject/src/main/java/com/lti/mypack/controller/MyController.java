package com.lti.mypack.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.mypack.model.Customer;
import com.lti.mypack.model.Product;
import com.lti.mypack.service.ProductService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/rest/api")
public class MyController 
{
		@Autowired
		ProductService pService;

			@GetMapping("/hello")
			public String sayHello()
			{
				return "Welcome to Spring Boot REST ";			
			}		
			@GetMapping("/mappings")
			public String Mapping()
			{
				pService.mappingExample();
				return "Welcome to Spring Boot REST ";			
			}	
			
			@PostMapping("/mapping/{itemid}")
			public boolean mappo(@RequestBody Customer custo,@PathVariable(value = "itemid") int itemid)
			{
				System.out.println(custo.getName()+custo.getId()+itemid);
				pService.addCust(custo,itemid);
				return true;
			}
			

			@GetMapping("/products")
			public List<Product> showProducts()
			{
				return pService.getAllProducts();
			}
			@PostMapping("/products")
			public String addProduct(@RequestBody Product product)
			{
				return pService.addProduct(product);
			}
			@PutMapping("/products")
			public String updProduct(@RequestBody Product product)
			{
				return pService.updProduct(product);
			}
			@DeleteMapping("/products")
			public String delProduct(@RequestBody Product product)
			{
				return pService.delProduct(product);
			}
			
			
			
}
