package com.lti.mypack.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="item001")
public class Item {
		
	@Id
	private int itemid;
	private String itemname;
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "itemdescription")
	ItemDetails idetails;
	
	
	public ItemDetails getIdetails() {
		return idetails;
	}
	public void setIdetails(ItemDetails idetails) {
		this.idetails = idetails;
	}

	/*
	 * @OneToOne(cascade = CascadeType.ALL, mappedBy = "item") private Customer
	 * customer;
	 */
	
	
	
}
