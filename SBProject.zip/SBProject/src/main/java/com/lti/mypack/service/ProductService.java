package com.lti.mypack.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.lti.mypack.model.Customer;
import com.lti.mypack.model.Item;
import com.lti.mypack.model.Product;
import com.lti.mypack.modelOTM.CustomerX;
import com.lti.mypack.modelOTM.ItemX;
import com.lti.mypack.repository.JPAItemRepo;
import com.lti.mypack.repository.JPARepo;
import com.lti.mypack.repository.JPARepo2;
import com.lti.mypack.repository.ProductRepository;

@Service
public class ProductService 
{
		@Autowired
		ProductRepository prodRepo;
		
		@Autowired
		JPARepo jpaRepo;
		
		@Autowired
		JPARepo2 jpaRepo2;
		
		@Autowired
		JPAItemRepo itemRepo;
	
		public List<Product> getAllProducts()
		{	
			return  prodRepo.getAllProducts();
		}
		public String addProduct(Product product)
		{
			return prodRepo.addProduct(product);
		}
		public String updProduct(Product product)
		{
			return "Updated";
		}
		public String delProduct(Product product) {
			
			return "Deleted";
		}
		public void mappingExample() {
			prodRepo.doMapping();	
		
			
		}
		public void addCust(Customer custo,int itemid) {
			
			Item item=itemRepo.findById(itemid).get();
			custo.setItem(item);
			jpaRepo2.save(custo);
			
		}
		
}
