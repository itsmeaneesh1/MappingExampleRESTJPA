package com.lti.mypack.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="itemdetails001")
public class ItemDetails
{
			@Id
			private int itdescid;
			
			private String description;

			public int getItdescid() {
				return itdescid;
			}

			public void setItdescid(int itdescid) {
				this.itdescid = itdescid;
			}

			public String getDescription() {
				return description;
			}

			public void setDescription(String description) {
				this.description = description;
			}
			
			
}
