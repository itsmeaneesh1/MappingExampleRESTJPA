package com.lti.mypack.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lti.mypack.model.Item;

public interface JPAItemRepo extends JpaRepository<Item, Integer>
{

}
